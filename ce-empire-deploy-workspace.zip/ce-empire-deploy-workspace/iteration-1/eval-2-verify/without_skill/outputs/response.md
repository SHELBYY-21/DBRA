# How to Check if Everything is Working After Deploying C.E. Empire

After deploying C.E. Empire, here are the key things to verify:

## 1. Check the Application is Running

- Open a browser and navigate to your deployed URL (or `http://localhost:<port>` if running locally).
- Confirm the app loads without errors (no blank screen, no 500/404 errors).

## 2. Check Server/Process Health

- If using a process manager (PM2, systemd, Docker, etc.), confirm the process is running:
  - **PM2:** `pm2 status` — look for "online" status.
  - **Docker:** `docker ps` — confirm the container is up.
  - **systemd:** `systemctl status <service-name>` — look for "active (running)".

## 3. Check Logs for Errors

- Review application logs for any startup errors or warnings:
  - **PM2:** `pm2 logs`
  - **Docker:** `docker logs <container-name>`
  - **Node/Python/etc.:** Check your log file or console output.
- Look for critical errors, unhandled exceptions, or failed connections.

## 4. Verify Database/Backend Connectivity

- If C.E. Empire uses a database, confirm it connected successfully (logs usually show this at startup).
- Try performing an action in the app that reads from or writes to the database.

## 5. Test Core Features

Walk through the main user flows to confirm they work end-to-end:
- Can you log in / authenticate?
- Can you view the main dashboard or home screen?
- Can you perform the primary actions (create, update, delete data, etc.)?

## 6. Check API Endpoints (if applicable)

- If there are REST or GraphQL endpoints, test a few key ones:
  - Use a browser, curl, or a tool like Postman/Insomnia.
  - Example: `curl https://your-domain.com/api/health` (if a health endpoint exists).
  - Expect a 200 OK response with valid data.

## 7. Verify Environment Variables and Configuration

- Confirm that environment variables (API keys, database URLs, secrets) are correctly set in the deployment environment.
- Misconfigured env vars are a common source of silent failures after deploy.

## 8. Check for a Health/Status Endpoint

- Many apps expose a `/health` or `/status` route. If C.E. Empire has one, hit it and confirm it returns a healthy response.

## 9. Monitor for a Few Minutes

- Watch logs in real-time for a minute or two after deployment to catch any delayed errors or crashes.
- Check memory and CPU usage to ensure the app isn't thrashing.

## 10. Smoke Test from a Fresh Browser Session

- Open an incognito/private browser window and go through the app as a new user would.
- This catches issues with cookies, session state, or caching that might not show up when you're already logged in.

---

If you encounter issues, the logs are your first stop. Share any error messages you see and I can help you diagnose them.
