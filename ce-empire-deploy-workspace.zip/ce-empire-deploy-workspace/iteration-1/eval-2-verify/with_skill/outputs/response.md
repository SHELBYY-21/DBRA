# How to Verify C.E. Empire After Deploying

Once Vercel says "Deployment Complete" and gives you a live URL, run through the steps below to confirm everything is working.

---

## 1. Login Test

1. Open your live URL in a browser (e.g. `https://ce-empire.vercel.app`)
2. You should see a login screen
3. Enter these credentials (they are case-sensitive):
   - **Username:** `BOSS`
   - **Password:** `Qw114477`
4. You should land on the Dashboard page

---

## 2. Feature Checklist

After logging in, check each of these one by one:

- [ ] **Dashboard loads** — KPI cards appear (Income, Expense, Profit, Margin)
- [ ] **Charts appear** — two graphs show below the KPI cards
- [ ] **Navigation works** — click each menu item: Income, Expense, Pending, Employees, Reports, Settings
- [ ] **Add a transaction** — try adding a test income entry and confirm it saves
- [ ] **Reports page** — go to Reports and confirm the charts there render correctly
- [ ] **Mobile check** — open the URL on your phone; it should resize and look clean

---

## 3. Console Check (Optional but Recommended)

This is the fastest way to confirm the app started up correctly:

1. On the live site, press **F12** on your keyboard (or right-click anywhere → "Inspect")
2. Click the **Console** tab
3. Look for this message:
   ```
   ✅ Application Ready with Charts & Auto-Refresh
   ```
4. If you see that message, everything is running correctly
5. If you see red error messages instead, see the troubleshooting notes below

---

## Common Problems and Fixes

**Charts are blank / graphs not showing**
The charts load from an external library (Chart.js) via the internet. Check that:
- You have an active internet connection
- Your `index.html` file contains this line:
  ```html
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
  ```
  If it's missing, add it back and redeploy.

**Page goes blank when you refresh**
This is handled automatically by the `vercel.json` file. If refreshing breaks the page, confirm that `vercel.json` was included when you uploaded your files. It must contain a `rewrites` section pointing back to `index.html`.

**Data I entered disappeared**
The site saves data in your browser, not on a server. Switching browsers or using private/incognito mode shows an empty slate. Use **Settings → Export** to back up your data as a file.

**Login doesn't work**
The credentials are case-sensitive. Make sure you're entering:
- Username: `BOSS` (all caps)
- Password: `Qw114477`

---

## Quick Reference

| Item | Value |
|------|-------|
| Live URL | `https://ce-empire.vercel.app` |
| Username | `BOSS` |
| Password | `Qw114477` |
| Expected console message | `✅ Application Ready with Charts & Auto-Refresh` |
| Vercel dashboard | https://vercel.com/dashboard |

If all items on the feature checklist pass and the console shows the ready message, your deployment is working correctly.
