# Putting the C.E. Empire Website Live on Vercel

Here is everything you need to get your C.E. Empire banking dashboard live on the internet. No coding required — just follow these steps in order.

---

## Before You Start — Check Your Files

Make sure you have all **17 files** in your project folder. The ones that must be present are:

- `index.html` — the main page
- `storage.js`, `charts.js`, `ui.js`, `app.js`, `calculator.js`, `ui-enhanced.js` — the business logic
- `vercel.json` — tells Vercel how to serve the site
- `package.json` — project settings
- `theme.css`, `components.css`, `responsive.css` — the design

If anything is missing, stop and resolve that first — the site won't work without the full set.

---

## Step 1 — Create a Free Vercel Account

Go to [https://vercel.com](https://vercel.com) and sign up for a free account if you don't have one. You can sign up with GitHub, GitLab, or just an email address.

---

## Step 2 — Deploy Your Files

1. Go to [https://vercel.com/new](https://vercel.com/new)
2. Look for the option to **drag and drop** your folder, or click **"Browse"** to select it
3. Select the **entire folder** containing all 17 files — not individual files, the whole folder
4. On the configuration screen, set:
   - **Project Name:** `ce-empire` (or any name you like)
   - **Framework Preset:** choose **Other** or **Static**
   - **Build Command:** leave this **empty**
   - **Output Directory:** type a single dot — `.`
   - **Environment Variables:** none needed
5. Click **Deploy**

Vercel will process your files. It usually takes under a minute. When it finishes, you'll see a green checkmark and a URL like:

```
https://ce-empire.vercel.app
```

Copy and save that URL — it's your live site.

---

## Step 3 — Verify Everything Works

Once deployed, run through this checklist:

### Login
1. Open your live URL in a browser
2. You should see a login screen
3. Enter these credentials (they are case-sensitive):
   - **Username:** `BOSS`
   - **Password:** `Qw114477`
4. You should land on the Dashboard page

### Check Each Feature
- [ ] Dashboard loads with KPI cards (Income, Expense, Profit, Margin)
- [ ] Two charts/graphs appear below the KPI cards
- [ ] Navigation menu works — click Income, Expense, Pending, Employees, Reports, Settings
- [ ] You can add a test transaction and it saves
- [ ] Reports page loads with charts rendered
- [ ] On your phone, the site resizes and looks clean

### Optional Console Check
1. On the live site, press **F12** (or right-click the page → "Inspect")
2. Click the **Console** tab
3. Look for this message:
   ```
   ✅ Application Ready with Charts & Auto-Refresh
   ```
   If you see red error messages instead, see the troubleshooting section below.

---

## Troubleshooting

**Charts are blank or not showing**
The charts need Chart.js to load from the internet. Check that `index.html` contains this line:
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
```
If it's missing, add it back and redeploy. Also try a different browser or network in case a CDN is being blocked.

**Page goes blank when I refresh**
This is handled automatically by the `vercel.json` file. If refreshing breaks the page, confirm that `vercel.json` was included when you uploaded your files. It should contain a `rewrites` section pointing everything back to `index.html`.

**My data disappeared**
The site saves data in your browser, not on a server. If you switch browsers, use incognito mode, or access from a different device, you'll see an empty slate. Use **Settings → Export** to back up your data as a file you can restore later.

**Login isn't working**
The credentials are case-sensitive. Double-check:
- Username: `BOSS` (all capital letters)
- Password: `Qw114477`

---

## After a Successful Deploy

1. **Share the URL** — send your Vercel URL to anyone who needs access
2. **Back up your data** — go to Settings → Export to download a JSON backup; keep it somewhere safe
3. **Add a custom domain** (optional) — in Vercel → Project Settings → Domains, you can connect your own domain (e.g. `empire.yourbusiness.com`)

---

## Quick Reference

| Item | Value |
|------|-------|
| Live URL | `https://ce-empire.vercel.app` (yours may differ) |
| Login username | `BOSS` |
| Login password | `Qw114477` |
| Expected console message | `✅ Application Ready with Charts & Auto-Refresh` |
| Vercel dashboard | https://vercel.com/dashboard |
| Total files to deploy | 17 |

---

Let me know once you have the URL and I can help you verify the live site is working correctly, or help you troubleshoot anything that comes up during deployment.
