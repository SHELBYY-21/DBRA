# Deploying the C.E. Empire Website to Vercel

After reviewing your project at `C:\CE\web`, here is what you need to know before deploying to Vercel.

---

## Important: This App Has Manus Platform Dependencies

Your project (`C:\CE\web`) was built on the **Manus web app template**. It has several dependencies that are tightly coupled to the Manus platform and will not work out-of-the-box on Vercel without significant changes:

| Dependency | What it does | Vercel situation |
|---|---|---|
| Manus OAuth (`VITE_OAUTH_PORTAL_URL`, `OAUTH_SERVER_URL`) | Handles login | Won't work — Manus-specific OAuth flow |
| `DATABASE_URL` (MySQL/TiDB) | Database connection | You must supply your own DB |
| `BUILT_IN_FORGE_API_URL` / `BUILT_IN_FORGE_API_KEY` | LLM, storage, notifications | Won't work — Manus internal API |
| `/manus-storage/` file serving | Static file/asset delivery | Won't work — Manus CDN |
| `JWT_SECRET` | Session cookies | You supply this yourself |

---

## What Vercel Can and Cannot Handle

Vercel is great for the **frontend (React/Vite)** and can run **serverless API routes**, but your app uses an Express server (`server/_core/index.ts`) as a long-running process. Vercel does not run long-lived Express servers natively — you would need to either:

- Convert the Express server to Vercel serverless functions, **or**
- Deploy the backend separately (e.g. Railway, Render, Fly.io) and host only the frontend on Vercel

---

## Option A: Deploy Frontend Only to Vercel (Simplest)

If the C.E. Empire site is primarily a **static/marketing site** and the backend features (auth, database, LLM) are not needed publicly, you can deploy just the Vite frontend:

### Steps

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Build the frontend**
   ```bash
   cd C:\CE\web
   pnpm install
   pnpm build
   ```
   This produces a `dist/` folder (the Vite output).

3. **Add a `vercel.json`** in `C:\CE\web` to tell Vercel to serve the static build:
   ```json
   {
     "buildCommand": "pnpm build",
     "outputDirectory": "dist",
     "installCommand": "pnpm install",
     "framework": "vite"
   }
   ```

4. **Deploy**
   ```bash
   vercel
   ```
   Follow the prompts. On first run it will ask you to log in and link a project.

5. **Set environment variables** in the Vercel dashboard under Settings > Environment Variables. At minimum:
   - `VITE_APP_ID` (if Manus OAuth is used on the frontend)
   - Any other `VITE_*` variables referenced in `client/src/const.ts`

> Note: API calls (tRPC routes at `/api/trpc`) will fail because the Express backend won't be running. Only the UI will be served.

---

## Option B: Full-Stack Deployment (Frontend on Vercel + Backend Elsewhere)

This is the recommended approach if you need the full app to work (auth, database, AI features).

### Backend: Deploy to Railway, Render, or Fly.io

These platforms support long-running Node.js servers and environment variables.

1. Push your repo to GitHub.
2. Connect Railway/Render to your repo.
3. Set all the required environment variables (see list above).
4. Set the start command to: `node dist/index.js` (after running `pnpm build`).
5. Note the backend URL (e.g. `https://ce-empire-api.railway.app`).

### Frontend: Deploy to Vercel

1. Add a `vercel.json` as shown in Option A.
2. Set `VITE_API_URL=https://ce-empire-api.railway.app` (or wherever your backend is) in Vercel environment variables.
3. Update your tRPC client in `client/src/lib/trpc.ts` to point to the backend URL in production.
4. Deploy with `vercel`.

---

## What You Will Need to Replace

Since Manus provides several services internally, you will need substitutes for production:

| Manus Feature | Open alternative |
|---|---|
| Manus OAuth | Clerk, Auth0, NextAuth, or custom JWT |
| MySQL/TiDB via `DATABASE_URL` | PlanetScale, Railway MySQL, Supabase Postgres |
| LLM via `BUILT_IN_FORGE_API_KEY` | Direct Anthropic API or OpenAI API key |
| File storage via `/manus-storage/` | Cloudflare R2, AWS S3, Uploadthing |
| Owner notifications | Email (Resend/SendGrid) or webhooks |

---

## Quickest Path to "Something Live"

If you just want the site visible on Vercel as fast as possible:

1. Run `pnpm build` in `C:\CE\web`
2. Run `vercel` from the same directory
3. Set any `VITE_*` env vars that are needed for the UI to render without crashing
4. Accept that backend features (login, database, AI) will not function until the backend is also deployed

---

## Need Help With a Specific Part?

Let me know which direction you want to go and I can:
- Write the `vercel.json` configuration
- Help you refactor the Express routes into Vercel serverless functions
- Set up a Railway/Render backend deployment
- Replace the Manus auth with a standard provider like Clerk or Auth0
