# Charts Not Showing Up on Live Site

This is a common deployment issue. Here are the most likely causes and fixes:

## 1. Missing or Failed Chart Library Import

If you're using a charting library (Chart.js, D3, Recharts, Highcharts, etc.), make sure it's properly included in production.

- Check your browser's **DevTools Console** (F12) for errors like `Chart is not defined` or `Cannot read properties of undefined`
- Verify the library is in your `dependencies` (not just `devDependencies`) in `package.json`
- If you're loading it via CDN, confirm the script tag is present in your deployed HTML

## 2. JavaScript Errors Blocking Rendering

Open DevTools > Console tab on the live site and look for red errors. A single JS error can prevent all subsequent code from running, including chart initialization.

## 3. Data Fetching Issues

Charts often render blank if the data they depend on fails to load:

- Check the **Network tab** in DevTools — are API calls returning 200 or erroring out (401, 404, 500)?
- Is your API URL hardcoded to `localhost` instead of the production URL?
- Are environment variables (like `REACT_APP_API_URL` or `VITE_API_URL`) set in your deployment platform?

## 4. Environment Variables Not Set

This is the most common culprit. If your chart data comes from an API and the URL is in an env var:

- In Vercel: Settings > Environment Variables
- In Netlify: Site settings > Environment variables
- In other platforms: check their dashboard for env config

After adding env vars, **redeploy** — they're baked in at build time for most frameworks.

## 5. SSR / Hydration Issues (Next.js, Nuxt, etc.)

If you're using server-side rendering, many chart libraries don't work on the server because they need the browser's `window` or `document`:

```js
// Next.js fix — dynamic import with SSR disabled
import dynamic from 'next/dynamic'
const MyChart = dynamic(() => import('../components/MyChart'), { ssr: false })
```

## 6. CSS / Container Size Issue

Charts sometimes render but are invisible because their container has zero height:

- Inspect the chart element — does it have `height: 0` or `display: none`?
- Many chart libraries require an explicit height on the wrapper element

## 7. Build Output Differences

- Run `npm run build` locally and check if charts work in the local production build (`npm run preview` or `npx serve dist`)
- This isolates whether it's a build issue vs. a deployment/environment issue

## Quick Diagnostic Steps

1. Open the live site, press **F12**
2. Check **Console** tab for errors
3. Check **Network** tab — filter by XHR/Fetch to see if data requests are succeeding
4. Inspect the chart's DOM element to see if it rendered at all (even if invisible)

If you share more details — which framework, which chart library, and any console errors — I can give more targeted help.
