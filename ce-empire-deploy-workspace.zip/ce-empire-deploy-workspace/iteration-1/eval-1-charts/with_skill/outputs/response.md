Charts not showing is a known issue — here's how to fix it.

## Why It Happens

The charts need an external library called **Chart.js** to draw the graphs. Your browser downloads this library from the internet every time the page loads. If that download fails, the chart areas stay blank.

---

## Step 1 — Check the Script Tag in index.html

Open your `index.html` file and search for this line:

```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
```

- **If that line is missing** — add it back (paste it just before the closing `</body>` tag), then redeploy to Vercel.
- **If the line is there** — move on to Step 2.

---

## Step 2 — Check the Browser Console for Errors

1. Open your live site in a browser
2. Press **F12** (or right-click anywhere → "Inspect")
3. Click the **Console** tab
4. Look at what's there:

| What you see | What it means |
|---|---|
| `✅ Application Ready with Charts & Auto-Refresh` | Everything loaded — the issue may be something else (see Step 3) |
| Red error mentioning `Chart` or `cdnjs` | Chart.js failed to load from the CDN |
| Any other red errors | A different script is broken — share the exact error message |

---

## Step 3 — Try These Quick Fixes

**Try a different browser** — if charts show in Chrome but not Edge (or vice versa), it's a browser-specific CDN block.

**Try a different network** — some corporate or school networks block CDN addresses. Switch to mobile data or a home connection and reload.

**Hard refresh** — press **Ctrl + Shift + R** (Windows) to force the browser to reload all files fresh instead of using a cached version.

---

## Step 4 — If Nothing Above Worked

Share the exact red error message from the Console tab (Step 2) and I can diagnose further. The most common messages and what they mean:

- `net::ERR_FAILED` on the Chart.js URL → CDN is being blocked on your network
- `Uncaught ReferenceError: Chart is not defined` → the script tag is missing or in the wrong place in `index.html`
- `Failed to load resource: 404` → the URL in the script tag has a typo

---

Once charts are working, you should see two graphs below the KPI cards on the Dashboard, and charts should also render on the Reports page.
